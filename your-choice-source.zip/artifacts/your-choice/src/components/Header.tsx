import { useState } from 'react'
import { Link, useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { ShoppingBag, Heart, Search, User, Menu, X, LogOut, Package } from 'lucide-react'
import { useApp } from '../store'

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Shop', href: '/shop' },
  { label: 'Men', href: '/shop?category=men' },
  { label: 'Women', href: '/shop?category=women' },
  { label: 'Kids', href: '/shop?category=kids' },
  { label: 'Accessories', href: '/shop?category=accessories' },
]

export default function Header() {
  const { cartCount, wishlistItems, user, logout, setCartOpen, setSearchOpen } = useApp()
  const [location, navigate] = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    setUserMenuOpen(false)
    navigate('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b border-luxury-gold/20 backdrop-blur-md bg-luxury-black/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="shrink-0 cursor-pointer">
          <h1 className="text-xl sm:text-2xl font-playfair font-bold text-luxury-gold leading-none">Your Choice</h1>
          <p className="text-luxury-light/50 text-[10px] tracking-widest uppercase hidden sm:block">Design My Style</p>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex gap-6 text-sm font-medium">
          {navLinks.map(l => (
            <Link
              key={l.href}
              href={l.href}
              className={`relative group transition-colors duration-200 ${location === l.href ? 'text-luxury-gold' : 'text-luxury-light/70 hover:text-luxury-gold'}`}
            >
              {l.label}
              <span className={`absolute -bottom-1 left-0 h-px bg-luxury-gold transition-all duration-300 ${location === l.href ? 'w-full' : 'w-0 group-hover:w-full'}`} />
            </Link>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button onClick={() => setSearchOpen(true)} className="p-2 text-luxury-light/70 hover:text-luxury-gold transition-colors" aria-label="Search">
            <Search className="w-5 h-5" />
          </button>

          <Link href="/wishlist" className="p-2 text-luxury-light/70 hover:text-red-400 transition-colors relative" aria-label="Wishlist">
            <Heart className="w-5 h-5" />
            {wishlistItems.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{wishlistItems.length}</span>
            )}
          </Link>

          <button onClick={() => setCartOpen(true)} className="p-2 text-luxury-light/70 hover:text-luxury-gold transition-colors relative" aria-label="Cart">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-luxury-gold text-luxury-black text-[10px] font-bold rounded-full flex items-center justify-center">{cartCount}</span>
            )}
          </button>

          {/* User */}
          <div className="relative">
            <button
              onClick={() => user ? setUserMenuOpen(v => !v) : navigate('/login')}
              className="p-2 text-luxury-light/70 hover:text-luxury-gold transition-colors"
              aria-label="Account"
            >
              <User className="w-5 h-5" />
            </button>

            <AnimatePresence>
              {userMenuOpen && user && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  className="absolute right-0 top-full mt-2 w-48 bg-luxury-black border border-luxury-gold/20 rounded-lg shadow-luxury-lg overflow-hidden"
                >
                  <div className="px-4 py-3 border-b border-luxury-gold/10">
                    <p className="text-sm font-semibold text-luxury-gold truncate">{user.name}</p>
                    <p className="text-xs text-luxury-light/50 truncate">{user.email}</p>
                  </div>
                  <Link href="/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-luxury-light/80 hover:text-luxury-gold hover:bg-luxury-gold/5 transition-colors">
                    <User className="w-4 h-4" /> Profile
                  </Link>
                  <Link href="/orders" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-luxury-light/80 hover:text-luxury-gold hover:bg-luxury-gold/5 transition-colors">
                    <Package className="w-4 h-4" /> My Orders
                  </Link>
                  {user.email === 'admin@yourchoice.com' && (
                    <Link href="/admin" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-luxury-gold hover:bg-luxury-gold/5 transition-colors">
                      <Package className="w-4 h-4" /> Admin Panel
                    </Link>
                  )}
                  <button onClick={handleLogout} className="flex items-center gap-2 w-full px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/5 transition-colors border-t border-luxury-gold/10">
                    <LogOut className="w-4 h-4" /> Logout
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Mobile hamburger */}
          <button className="lg:hidden p-2 text-luxury-light/70 hover:text-luxury-gold transition-colors" onClick={() => setMobileOpen(v => !v)}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden overflow-hidden border-t border-luxury-gold/10"
          >
            <div className="px-4 py-3 space-y-1">
              {navLinks.map(l => (
                <Link
                  key={l.href}
                  href={l.href}
                  onClick={() => setMobileOpen(false)}
                  className="block py-2 text-sm text-luxury-light/80 hover:text-luxury-gold transition-colors"
                >
                  {l.label}
                </Link>
              ))}
              {user ? (
                <>
                  <Link href="/profile" onClick={() => setMobileOpen(false)} className="block py-2 text-sm text-luxury-light/80 hover:text-luxury-gold transition-colors">Profile</Link>
                  <Link href="/orders" onClick={() => setMobileOpen(false)} className="block py-2 text-sm text-luxury-light/80 hover:text-luxury-gold transition-colors">My Orders</Link>
                  <button onClick={() => { handleLogout(); setMobileOpen(false) }} className="block py-2 text-sm text-red-400">Logout</button>
                </>
              ) : (
                <Link href="/login" onClick={() => setMobileOpen(false)} className="block py-2 text-sm text-luxury-gold">Login / Register</Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay for user menu */}
      {userMenuOpen && <div className="fixed inset-0 z-[-1]" onClick={() => setUserMenuOpen(false)} />}
    </header>
  )
}
