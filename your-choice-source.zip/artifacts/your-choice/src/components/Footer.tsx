import { Link } from 'wouter'
import { motion } from 'framer-motion'
import { Phone, MapPin, Facebook, Instagram, Twitter } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-white/[0.02] border-t border-luxury-gold/15 pt-14 pb-8 px-4 mt-auto">
      <div className="max-w-7xl mx-auto">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div>
            <h4 className="font-playfair font-bold text-luxury-gold text-xl mb-1">Your Choice</h4>
            <p className="text-[10px] tracking-widest uppercase text-luxury-light/40 mb-4">Design My Style</p>
            <p className="text-sm text-luxury-light/60 leading-relaxed mb-5">Premium ethnic & fashion wear for the modern family. Your style, your choice.</p>
            <div className="flex gap-2">
              {[Facebook, Instagram, Twitter].map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ scale: 1.15, backgroundColor: 'rgba(212,175,55,0.25)' }}
                  className="w-8 h-8 bg-luxury-gold/10 border border-luxury-gold/20 rounded-full flex items-center justify-center text-luxury-gold transition-colors"
                >
                  <Icon className="w-3.5 h-3.5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h5 className="font-semibold text-luxury-light mb-4 tracking-wide">Quick Links</h5>
            <ul className="space-y-2 text-sm text-luxury-light/60">
              {[['Home', '/'], ['Shop All', '/shop'], ['Men Collection', '/shop?category=men'], ['Women Collection', '/shop?category=women'], ['Kids Collection', '/shop?category=kids']].map(([l, h]) => (
                <li key={h}><Link href={h} className="hover:text-luxury-gold transition-colors duration-200">{l}</Link></li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h5 className="font-semibold text-luxury-light mb-4 tracking-wide">Support</h5>
            <ul className="space-y-2 text-sm text-luxury-light/60">
              {['Privacy Policy', 'Terms & Conditions', 'Refund Policy', 'Shipping Policy', 'FAQ'].map(l => (
                <li key={l}><a href="#" className="hover:text-luxury-gold transition-colors duration-200">{l}</a></li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h5 className="font-semibold text-luxury-light mb-4 tracking-wide">Contact Us</h5>
            <div className="space-y-3 text-sm text-luxury-light/60">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-luxury-gold shrink-0 mt-0.5" />
                <span>C/O Bhawani Medical Store</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-luxury-gold shrink-0" />
                <div>
                  <p>Arvind: <a href="tel:9467259111" className="hover:text-luxury-gold">9467259111</a></p>
                  <p>Karan: <a href="tel:8950114418" className="hover:text-luxury-gold">8950114418</a></p>
                </div>
              </div>
              <a
                href="https://wa.me/919467259111"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-2 px-3 py-1.5 bg-green-600/20 border border-green-500/30 rounded text-green-400 text-xs hover:bg-green-600/30 transition-colors"
              >
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-luxury-gold/10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-luxury-light/30">
          <p>&copy; 2024 Your Choice E-Commerce. All rights reserved.</p>
          <p>Design My Style | Your Style, Your Choice</p>
        </div>
      </div>
    </footer>
  )
}
