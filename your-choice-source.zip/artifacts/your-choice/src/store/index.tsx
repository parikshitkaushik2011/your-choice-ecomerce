import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { Product } from '../data/products'

export interface CartItem {
  product: Product
  size: string
  color: string
  quantity: number
}

export interface Address {
  fullName: string
  phone: string
  street: string
  city: string
  state: string
  pincode: string
}

export interface Order {
  id: string
  items: CartItem[]
  total: number
  status: 'Confirmed' | 'Processing' | 'Shipped' | 'Delivered'
  date: string
  address: Address
  paymentMethod: string
}

export interface User {
  name: string
  email: string
  phone: string
  password: string
}

interface AppContextType {
  cartItems: CartItem[]
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void
  removeFromCart: (productId: string, size: string, color: string) => void
  updateQuantity: (productId: string, size: string, color: string, qty: number) => void
  clearCart: () => void
  cartTotal: number
  cartCount: number

  wishlistItems: Product[]
  toggleWishlist: (product: Product) => void
  isInWishlist: (productId: string) => boolean

  user: User | null
  login: (email: string, password: string) => boolean
  register: (name: string, email: string, password: string, phone: string) => boolean
  logout: () => void
  updateUser: (data: Partial<User>) => void

  orders: Order[]
  placeOrder: (address: Address, paymentMethod: string) => string

  isCartOpen: boolean
  setCartOpen: (v: boolean) => void
  isSearchOpen: boolean
  setSearchOpen: (v: boolean) => void
}

const AppContext = createContext<AppContextType | null>(null)

function load<T>(key: string, fallback: T): T {
  try {
    const s = localStorage.getItem(key)
    return s ? JSON.parse(s) : fallback
  } catch {
    return fallback
  }
}

function save(key: string, value: unknown) {
  localStorage.setItem(key, JSON.stringify(value))
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => load('yc_cart', []))
  const [wishlistItems, setWishlistItems] = useState<Product[]>(() => load('yc_wishlist', []))
  const [user, setUser] = useState<User | null>(() => load('yc_user', null))
  const [orders, setOrders] = useState<Order[]>(() => load('yc_orders', []))
  const [isCartOpen, setCartOpen] = useState(false)
  const [isSearchOpen, setSearchOpen] = useState(false)

  useEffect(() => { save('yc_cart', cartItems) }, [cartItems])
  useEffect(() => { save('yc_wishlist', wishlistItems) }, [wishlistItems])
  useEffect(() => { save('yc_user', user) }, [user])
  useEffect(() => { save('yc_orders', orders) }, [orders])

  const cartCount = cartItems.reduce((s, i) => s + i.quantity, 0)
  const cartTotal = cartItems.reduce((s, i) => s + i.product.price * i.quantity, 0)

  const addToCart = (product: Product, size: string, color: string, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.product.id === product.id && i.size === size && i.color === color)
      if (existing) {
        return prev.map(i =>
          i.product.id === product.id && i.size === size && i.color === color
            ? { ...i, quantity: i.quantity + quantity }
            : i
        )
      }
      return [...prev, { product, size, color, quantity }]
    })
  }

  const removeFromCart = (productId: string, size: string, color: string) => {
    setCartItems(prev => prev.filter(i => !(i.product.id === productId && i.size === size && i.color === color)))
  }

  const updateQuantity = (productId: string, size: string, color: string, qty: number) => {
    if (qty <= 0) {
      removeFromCart(productId, size, color)
      return
    }
    setCartItems(prev =>
      prev.map(i =>
        i.product.id === productId && i.size === size && i.color === color ? { ...i, quantity: qty } : i
      )
    )
  }

  const clearCart = () => setCartItems([])

  const toggleWishlist = (product: Product) => {
    setWishlistItems(prev =>
      prev.find(p => p.id === product.id) ? prev.filter(p => p.id !== product.id) : [...prev, product]
    )
  }

  const isInWishlist = (productId: string) => wishlistItems.some(p => p.id === productId)

  const login = (email: string, password: string): boolean => {
    const stored = load<Record<string, User>>('yc_users', {})
    const found = Object.values(stored).find(u => u.email === email && u.password === password)
    if (found) { setUser(found); return true }
    return false
  }

  const register = (name: string, email: string, password: string, phone: string): boolean => {
    const stored = load<Record<string, User>>('yc_users', {})
    if (Object.values(stored).find(u => u.email === email)) return false
    const newUser: User = { name, email, password, phone }
    save('yc_users', { ...stored, [email]: newUser })
    setUser(newUser)
    return true
  }

  const logout = () => setUser(null)

  const updateUser = (data: Partial<User>) => {
    if (!user) return
    const updated = { ...user, ...data }
    setUser(updated)
    const stored = load<Record<string, User>>('yc_users', {})
    save('yc_users', { ...stored, [updated.email]: updated })
  }

  const placeOrder = (address: Address, paymentMethod: string): string => {
    const id = 'YC' + Date.now()
    const order: Order = {
      id,
      items: [...cartItems],
      total: cartTotal,
      status: 'Confirmed',
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      address,
      paymentMethod,
    }
    setOrders(prev => [order, ...prev])
    clearCart()
    return id
  }

  return (
    <AppContext.Provider value={{
      cartItems, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount,
      wishlistItems, toggleWishlist, isInWishlist,
      user, login, register, logout, updateUser,
      orders, placeOrder,
      isCartOpen, setCartOpen, isSearchOpen, setSearchOpen,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
