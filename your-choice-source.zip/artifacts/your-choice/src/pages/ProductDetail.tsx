import { useState } from 'react'
import { useParams, useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { Heart, ShoppingBag, Star, Shield, Truck, RefreshCw, ChevronDown, ChevronUp, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'
import ProductCard from '../components/ProductCard'
import { getProductById, getRelatedProducts } from '../data/products'
import { useApp } from '../store'

const mockReviews = [
  { name: 'Priya S.', rating: 5, date: '15 Dec 2024', comment: 'Absolutely gorgeous! The quality is outstanding and it fits perfectly. Will definitely buy again.' },
  { name: 'Rahul M.', rating: 4, date: '8 Dec 2024', comment: 'Great product, exactly as described. Fast delivery and well packaged.' },
  { name: 'Anita K.', rating: 5, date: '1 Dec 2024', comment: 'Loved it! The fabric quality is premium and the colour is exactly as shown. Very happy with the purchase.' },
]

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>()
  const [, navigate] = useLocation()
  const { addToCart, toggleWishlist, isInWishlist, setCartOpen } = useApp()
  const product = getProductById(id || '')

  const [selectedSize, setSelectedSize] = useState('')
  const [selectedColor, setSelectedColor] = useState('')
  const [quantity, setQuantity] = useState(1)
  const [detailsOpen, setDetailsOpen] = useState(false)

  if (!product) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-6xl">🔍</p>
        <p className="text-luxury-light/60">Product not found</p>
        <button onClick={() => navigate('/shop')} className="px-5 py-2 bg-luxury-gold text-luxury-black font-bold rounded-lg">Back to Shop</button>
      </div>
    )
  }

  const inWishlist = isInWishlist(product.id)
  const discount = Math.round((1 - product.price / product.originalPrice) * 100)
  const related = getRelatedProducts(product)

  const handleAddToCart = () => {
    const size = selectedSize || product.sizes[0]
    const color = selectedColor || product.colors[0]?.name || 'Default'
    addToCart(product, size, color, quantity)
    toast.success('Added to cart!', { icon: '🛒' })
    setCartOpen(true)
  }

  const handleBuyNow = () => {
    const size = selectedSize || product.sizes[0]
    const color = selectedColor || product.colors[0]?.name || 'Default'
    addToCart(product, size, color, quantity)
    navigate('/checkout')
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Back */}
      <button onClick={() => navigate('/shop')} className="flex items-center gap-1.5 text-sm text-luxury-light/50 hover:text-luxury-gold transition-colors mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to Shop
      </button>

      <div className="grid lg:grid-cols-2 gap-10 mb-16">
        {/* Image */}
        <div>
          <div className="aspect-square bg-gradient-to-b from-luxury-gold/8 to-luxury-black rounded-3xl border border-luxury-gold/20 flex items-center justify-center mb-4 relative overflow-hidden">
            {product.isNew && (
              <div className="absolute top-4 left-4 px-3 py-1 bg-luxury-gold text-luxury-black text-xs font-bold rounded-full">NEW</div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-luxury-black/30 to-transparent pointer-events-none" />
            <motion.span
              className="text-[140px] sm:text-[180px] leading-none select-none"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            >
              {product.emoji}
            </motion.span>
          </div>

          {/* Thumbnails (same emoji, different colors) */}
          <div className="flex gap-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-20 h-20 bg-luxury-gold/5 border border-luxury-gold/20 rounded-xl flex items-center justify-center text-4xl cursor-pointer hover:border-luxury-gold/50 transition-colors">
                {product.emoji}
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">{product.category} · {product.subcategory}</p>
              <h1 className="text-2xl sm:text-3xl font-playfair font-bold leading-tight">{product.name}</h1>
            </div>
            <motion.button
              onClick={() => { toggleWishlist(product); toast(inWishlist ? 'Removed from wishlist' : 'Added to wishlist!', { icon: inWishlist ? '💔' : '❤️' }) }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className={`p-2.5 rounded-full border transition-all shrink-0 ${inWishlist ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'border-luxury-gold/20 text-luxury-light/50 hover:text-red-400 hover:border-red-400/30'}`}
            >
              <Heart className={`w-5 h-5 ${inWishlist ? 'fill-red-400' : ''}`} />
            </motion.button>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-luxury-gold fill-luxury-gold' : 'text-luxury-gold/20'}`} />
              ))}
            </div>
            <span className="text-sm font-semibold text-luxury-gold">{product.rating}</span>
            <span className="text-sm text-luxury-light/40">({product.reviewCount} reviews)</span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 mb-6 p-4 bg-luxury-gold/5 rounded-xl border border-luxury-gold/15">
            <span className="text-3xl font-playfair font-bold text-luxury-gold">₹{product.price.toLocaleString()}</span>
            <span className="text-luxury-light/30 line-through text-lg">₹{product.originalPrice.toLocaleString()}</span>
            <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-sm font-bold rounded">{discount}% OFF</span>
          </div>

          {/* Description */}
          <p className="text-luxury-light/70 text-sm leading-relaxed mb-6">{product.description}</p>

          {/* Colors */}
          {product.colors.length > 0 && (
            <div className="mb-5">
              <p className="text-sm font-semibold mb-2">Color: <span className="text-luxury-gold">{selectedColor || product.colors[0].name}</span></p>
              <div className="flex gap-2">
                {product.colors.map(c => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColor(c.name)}
                    title={c.name}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${selectedColor === c.name || (!selectedColor && c === product.colors[0]) ? 'border-luxury-gold scale-110' : 'border-luxury-light/20 hover:border-luxury-gold/60'}`}
                    style={{ backgroundColor: c.hex }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {product.sizes.length > 1 && (
            <div className="mb-6">
              <p className="text-sm font-semibold mb-2">Size: <span className="text-luxury-gold">{selectedSize || 'Select Size'}</span></p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(s => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`px-3 py-1.5 text-xs border rounded-lg transition-all font-medium ${selectedSize === s ? 'bg-luxury-gold text-luxury-black border-luxury-gold' : 'border-luxury-gold/25 text-luxury-light/70 hover:border-luxury-gold hover:text-luxury-gold'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div className="flex items-center gap-4 mb-6">
            <p className="text-sm font-semibold">Qty:</p>
            <div className="flex items-center gap-3 border border-luxury-gold/25 rounded-xl px-3 py-2">
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="text-luxury-gold hover:text-luxury-gold/60 transition-colors font-bold text-lg w-5 text-center">−</button>
              <span className="w-8 text-center font-semibold">{quantity}</span>
              <button onClick={() => setQuantity(q => q + 1)} className="text-luxury-gold hover:text-luxury-gold/60 transition-colors font-bold text-lg w-5 text-center">+</button>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 mb-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleAddToCart}
              className="flex-1 py-3 flex items-center justify-center gap-2 bg-luxury-gold/15 text-luxury-gold border border-luxury-gold/30 rounded-xl font-bold hover:bg-luxury-gold hover:text-luxury-black transition-all"
            >
              <ShoppingBag className="w-4 h-4" /> Add to Cart
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleBuyNow}
              className="flex-1 py-3 bg-luxury-gold text-luxury-black rounded-xl font-bold hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
            >
              Buy Now
            </motion.button>
          </div>

          {/* Trust badges */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { icon: Shield, label: '100% Authentic' },
              { icon: Truck, label: 'Fast Delivery' },
              { icon: RefreshCw, label: 'Easy Returns' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-1 p-2 border border-luxury-gold/10 rounded-lg text-center">
                <Icon className="w-4 h-4 text-luxury-gold" />
                <span className="text-[10px] text-luxury-light/50">{label}</span>
              </div>
            ))}
          </div>

          {/* Product Details Accordion */}
          <div className="border border-luxury-gold/15 rounded-xl overflow-hidden">
            <button
              onClick={() => setDetailsOpen(v => !v)}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold hover:bg-luxury-gold/5 transition-colors"
            >
              Product Details
              {detailsOpen ? <ChevronUp className="w-4 h-4 text-luxury-gold" /> : <ChevronDown className="w-4 h-4 text-luxury-gold" />}
            </button>
            {detailsOpen && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="px-4 pb-4 border-t border-luxury-gold/10"
              >
                <ul className="mt-3 space-y-1.5">
                  {product.details.map(d => (
                    <li key={d} className="flex items-start gap-2 text-sm text-luxury-light/60">
                      <span className="text-luxury-gold mt-0.5">•</span> {d}
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mb-16">
        <h2 className="text-2xl font-playfair font-bold mb-6">Customer Reviews</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          {mockReviews.map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-4 border border-luxury-gold/15 rounded-xl bg-white/[0.02]"
            >
              <div className="flex items-center gap-1 mb-2">
                {[...Array(r.rating)].map((_, j) => <Star key={j} className="w-3.5 h-3.5 text-luxury-gold fill-luxury-gold" />)}
              </div>
              <p className="text-sm text-luxury-light/70 mb-3 italic">"{r.comment}"</p>
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-luxury-gold">{r.name}</span>
                <span className="text-xs text-luxury-light/30">{r.date}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section>
          <h2 className="text-2xl font-playfair font-bold mb-6">You May Also Like</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  )
}
