import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { Trash2, Plus, Minus, ShoppingBag, Tag, ArrowRight } from 'lucide-react'
import { useApp } from '../store'

const COUPONS: Record<string, number> = {
  YOURCHOICE20: 20,
  FESTIVE10: 10,
  FIRST15: 15,
}

export default function Cart() {
  const { cartItems, removeFromCart, updateQuantity, cartTotal } = useApp()
  const [, navigate] = useLocation()
  const [coupon, setCoupon] = useState('')
  const [appliedCoupon, setAppliedCoupon] = useState('')
  const [couponError, setCouponError] = useState('')
  const [couponMsg, setCouponMsg] = useState('')

  const discount = appliedCoupon ? COUPONS[appliedCoupon] : 0
  const discountAmt = Math.round(cartTotal * discount / 100)
  const deliveryFee = cartTotal > 5000 ? 0 : 99
  const finalTotal = cartTotal - discountAmt + deliveryFee

  const applyCoupon = () => {
    const code = coupon.trim().toUpperCase()
    if (COUPONS[code]) {
      setAppliedCoupon(code)
      setCouponError('')
      setCouponMsg(`${COUPONS[code]}% discount applied!`)
    } else {
      setCouponError('Invalid coupon code')
      setCouponMsg('')
    }
  }

  const removeCoupon = () => {
    setAppliedCoupon('')
    setCoupon('')
    setCouponMsg('')
    setCouponError('')
  }

  if (cartItems.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <ShoppingBag className="w-20 h-20 text-luxury-gold/20 mx-auto mb-6" />
          <h2 className="text-2xl font-playfair font-bold mb-3">Your cart is empty</h2>
          <p className="text-luxury-light/50 mb-8 text-sm">Looks like you haven't added anything to your cart yet.</p>
          <button onClick={() => navigate('/shop')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all">
            Start Shopping
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-playfair font-bold mb-8">Your Cart <span className="text-luxury-gold text-xl ml-2">({cartItems.length} items)</span></h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          <AnimatePresence mode="popLayout">
            {cartItems.map(item => (
              <motion.div
                key={`${item.product.id}-${item.size}-${item.color}`}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex gap-4 p-4 bg-white/[0.02] border border-luxury-gold/15 rounded-2xl hover:border-luxury-gold/30 transition-colors"
              >
                <div
                  className="w-24 h-24 sm:w-28 sm:h-28 bg-luxury-gold/5 rounded-xl flex items-center justify-center border border-luxury-gold/10 cursor-pointer shrink-0"
                  onClick={() => navigate(`/product/${item.product.id}`)}
                >
                  <span className="text-5xl">{item.product.emoji}</span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex justify-between gap-2">
                    <div>
                      <p className="text-[10px] text-luxury-gold/60 uppercase tracking-widest">{item.product.subcategory}</p>
                      <h3 className="font-playfair font-semibold text-sm sm:text-base mt-0.5 cursor-pointer hover:text-luxury-gold transition-colors" onClick={() => navigate(`/product/${item.product.id}`)}>
                        {item.product.name}
                      </h3>
                      <p className="text-xs text-luxury-light/40 mt-0.5">Size: {item.size} · {item.color}</p>
                    </div>
                    <button onClick={() => removeFromCart(item.product.id, item.size, item.color)} className="text-red-400/50 hover:text-red-400 transition-colors shrink-0 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-luxury-gold/20 rounded-lg overflow-hidden">
                      <button onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity - 1)} className="px-2.5 py-1.5 hover:bg-luxury-gold/10 transition-colors text-luxury-gold">
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 py-1.5 text-sm font-semibold border-x border-luxury-gold/20">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity + 1)} className="px-2.5 py-1.5 hover:bg-luxury-gold/10 transition-colors text-luxury-gold">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-luxury-gold">₹{(item.product.price * item.quantity).toLocaleString()}</p>
                      {item.quantity > 1 && <p className="text-xs text-luxury-light/30">₹{item.product.price.toLocaleString()} each</p>}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 border border-luxury-gold/20 rounded-2xl p-5 bg-white/[0.02]">
            <h3 className="font-playfair font-bold text-lg mb-5 text-luxury-gold">Order Summary</h3>

            {/* Coupon */}
            <div className="mb-5">
              {appliedCoupon ? (
                <div className="flex items-center justify-between px-3 py-2 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-green-400" />
                    <span className="text-sm font-semibold text-green-400">{appliedCoupon}</span>
                    <span className="text-xs text-green-400">-{discount}%</span>
                  </div>
                  <button onClick={removeCoupon} className="text-green-400/60 hover:text-red-400 transition-colors text-xs">Remove</button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input
                    value={coupon}
                    onChange={e => setCoupon(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && applyCoupon()}
                    placeholder="Enter coupon code"
                    className="flex-1 px-3 py-2 text-xs bg-white/5 border border-luxury-gold/20 rounded-lg text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors"
                  />
                  <button onClick={applyCoupon} className="px-3 py-2 border border-luxury-gold/30 text-luxury-gold text-xs rounded-lg hover:bg-luxury-gold/5 transition-colors font-semibold">
                    Apply
                  </button>
                </div>
              )}
              {couponError && <p className="text-xs text-red-400 mt-1">{couponError}</p>}
              {couponMsg && <p className="text-xs text-green-400 mt-1">{couponMsg}</p>}
              <p className="text-[10px] text-luxury-light/30 mt-2">Try: YOURCHOICE20, FESTIVE10, FIRST15</p>
            </div>

            {/* Breakdown */}
            <div className="space-y-2.5 text-sm border-t border-luxury-gold/10 pt-4 mb-4">
              <div className="flex justify-between text-luxury-light/60">
                <span>Subtotal</span>
                <span>₹{cartTotal.toLocaleString()}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-400">
                  <span>Discount ({discount}%)</span>
                  <span>-₹{discountAmt.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-luxury-light/60">
                <span>Delivery</span>
                <span>{deliveryFee === 0 ? <span className="text-green-400">FREE</span> : `₹${deliveryFee}`}</span>
              </div>
              {cartTotal < 5000 && (
                <p className="text-[10px] text-luxury-light/30">Add ₹{(5000 - cartTotal).toLocaleString()} more for free delivery</p>
              )}
            </div>

            <div className="flex justify-between font-bold text-lg border-t border-luxury-gold/15 pt-4 mb-5">
              <span>Total</span>
              <span className="text-luxury-gold font-playfair">₹{finalTotal.toLocaleString()}</span>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate('/checkout')}
              className="w-full py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2"
            >
              Proceed to Checkout <ArrowRight className="w-4 h-4" />
            </motion.button>

            <button onClick={() => navigate('/shop')} className="w-full mt-3 py-2.5 border border-luxury-gold/20 text-luxury-gold/70 text-sm rounded-xl hover:bg-luxury-gold/5 transition-colors">
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
