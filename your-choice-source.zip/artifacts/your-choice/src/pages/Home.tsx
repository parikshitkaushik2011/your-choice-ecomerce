import { useState, useEffect } from 'react'
import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import { getFeaturedProducts, getNewArrivals } from '../data/products'

const heroSlides = [
  {
    title: 'Your Style,',
    highlight: 'Your Choice',
    sub: 'Premium Ladies & Gents Garments',
    tag: 'New Collection 2024',
    btn: 'Shop Now',
    href: '/shop',
    bg: 'from-luxury-gold/10 via-luxury-black to-luxury-black',
    emoji: '👗',
  },
  {
    title: 'Bridal',
    highlight: 'Elegance',
    sub: 'Exquisite Wedding Collection',
    tag: 'Bridal Wear',
    btn: 'Explore Collection',
    href: '/shop?category=women',
    bg: 'from-rose-900/20 via-luxury-black to-luxury-black',
    emoji: '💍',
  },
  {
    title: 'Regal Men\'s',
    highlight: 'Fashion',
    sub: 'Sherwanis, Suits & Kurtas',
    tag: 'Men\'s Exclusive',
    btn: 'Shop Men',
    href: '/shop?category=men',
    bg: 'from-blue-900/20 via-luxury-black to-luxury-black',
    emoji: '🎩',
  },
]

const categories = [
  { name: 'Men', emoji: '👔', sub: 'Sherwanis, Suits & Kurtas', href: '/shop?category=men', count: 6 },
  { name: 'Women', emoji: '👗', sub: 'Sarees, Lehengas & Suits', href: '/shop?category=women', count: 6 },
  { name: 'Kids', emoji: '👶', sub: 'Ethnic & Casual Wear', href: '/shop?category=kids', count: 6 },
  { name: 'Accessories', emoji: '💎', sub: 'Jewellery, Bags & More', href: '/shop?category=accessories', count: 6 },
]

const features = [
  { icon: '✓', title: '100% Original', desc: 'Authentic guaranteed' },
  { icon: '📦', title: 'Local Delivery', desc: 'Fast & reliable' },
  { icon: '🔒', title: 'Secure Payments', desc: 'Safe transactions' },
  { icon: '↩️', title: 'Easy Returns', desc: 'Hassle-free policy' },
  { icon: '📞', title: '24/7 Support', desc: 'Always here to help' },
]

export default function Home() {
  const [, navigate] = useLocation()
  const [slide, setSlide] = useState(0)
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)
  const featured = getFeaturedProducts()
  const newArrivals = getNewArrivals()

  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % heroSlides.length), 5000)
    return () => clearInterval(t)
  }, [])

  const prev = () => setSlide(s => (s - 1 + heroSlides.length) % heroSlides.length)
  const next = () => setSlide(s => (s + 1) % heroSlides.length)

  return (
    <div>
      {/* Hero Slider */}
      <section className="relative h-[90vh] min-h-[500px] max-h-[800px] overflow-hidden">
        <AnimatePresence mode="wait">
          {heroSlides.map((h, i) =>
            i === slide ? (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 60 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -60 }}
                transition={{ duration: 0.5 }}
                className={`absolute inset-0 bg-gradient-to-br ${h.bg} flex items-center`}
              >
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.07)_0%,_transparent_60%)] pointer-events-none" />
                <div className="max-w-7xl mx-auto px-6 w-full flex items-center justify-between">
                  <div className="max-w-xl">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="inline-flex items-center gap-2 mb-5 px-3 py-1 border border-luxury-gold/40 rounded-full text-luxury-gold text-xs tracking-widest uppercase"
                    >
                      <Sparkles className="w-3 h-3" /> {h.tag}
                    </motion.div>
                    <motion.h1
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="text-5xl sm:text-6xl md:text-7xl font-playfair font-bold leading-tight mb-4"
                    >
                      {h.title}<br />
                      <span className="text-luxury-gold">{h.highlight}</span>
                    </motion.h1>
                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="text-lg text-luxury-light/70 mb-8"
                    >
                      {h.sub}
                    </motion.p>
                    <motion.button
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      onClick={() => navigate(h.href)}
                      whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(212,175,55,0.4)' }}
                      whileTap={{ scale: 0.97 }}
                      className="flex items-center gap-2 px-8 py-3.5 bg-luxury-gold text-luxury-black font-bold rounded-xl text-base"
                    >
                      {h.btn} <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                  <motion.div
                    initial={{ opacity: 0, scale: 0.7 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                    className="hidden md:flex text-[180px] leading-none select-none"
                    style={{ filter: 'drop-shadow(0 0 60px rgba(212,175,55,0.2))' }}
                  >
                    {h.emoji}
                  </motion.div>
                </div>
              </motion.div>
            ) : null
          )}
        </AnimatePresence>

        {/* Slide controls */}
        <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-luxury-black/60 border border-luxury-gold/20 rounded-full flex items-center justify-center text-luxury-gold hover:bg-luxury-gold hover:text-luxury-black transition-all">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-luxury-black/60 border border-luxury-gold/20 rounded-full flex items-center justify-center text-luxury-gold hover:bg-luxury-gold hover:text-luxury-black transition-all">
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Dots */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
          {heroSlides.map((_, i) => (
            <button key={i} onClick={() => setSlide(i)} className={`w-2 h-2 rounded-full transition-all ${i === slide ? 'w-6 bg-luxury-gold' : 'bg-luxury-gold/30'}`} />
          ))}
        </div>

        {/* Stats */}
        <div className="absolute bottom-6 right-6 hidden sm:flex gap-6 text-center z-10">
          {[['500+', 'Products'], ['10K+', 'Customers'], ['5★', 'Rated']].map(([n, l]) => (
            <div key={l}>
              <div className="text-luxury-gold font-playfair font-bold text-xl">{n}</div>
              <div className="text-luxury-light/40 text-xs">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-10 px-4 border-y border-luxury-gold/10 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="text-center p-4 border border-luxury-gold/10 rounded-xl hover:border-luxury-gold/40 transition-all bg-white/[0.02]"
            >
              <p className="text-2xl mb-2">{f.icon}</p>
              <h3 className="text-xs font-semibold text-luxury-gold font-playfair">{f.title}</h3>
              <p className="text-[10px] text-luxury-light/50 mt-0.5">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-luxury-gold text-xs tracking-widest uppercase mb-2">Browse By</p>
            <h2 className="text-3xl font-playfair font-bold">Shop By Category</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {categories.map((c, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                onClick={() => navigate(c.href)}
                whileHover={{ y: -6 }}
                className="group text-left"
              >
                <div className="relative h-48 bg-gradient-to-br from-luxury-gold/8 to-luxury-black rounded-2xl flex items-center justify-center border border-luxury-gold/15 group-hover:border-luxury-gold/60 transition-all overflow-hidden mb-3">
                  <div className="absolute inset-0 bg-gradient-to-t from-luxury-black/60 to-transparent pointer-events-none" />
                  <motion.span className="text-6xl" whileHover={{ scale: 1.15, rotate: -5 }} transition={{ duration: 0.3 }}>
                    {c.emoji}
                  </motion.span>
                  <div className="absolute bottom-3 right-3 w-7 h-7 bg-luxury-gold rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowRight className="w-3.5 h-3.5 text-luxury-black" />
                  </div>
                </div>
                <h3 className="font-playfair font-bold text-base group-hover:text-luxury-gold transition-colors">{c.name} Collection</h3>
                <p className="text-xs text-luxury-light/50 mt-0.5">{c.sub}</p>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 px-4 bg-white/[0.015]">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-luxury-gold text-xs tracking-widest uppercase mb-2">Handpicked</p>
              <h2 className="text-3xl font-playfair font-bold">Featured Products</h2>
            </div>
            <button onClick={() => navigate('/shop')} className="flex items-center gap-1 text-sm text-luxury-gold hover:underline">
              View All <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* Offer Banner */}
      <section className="py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onClick={() => navigate('/shop')}
            className="relative rounded-3xl overflow-hidden border border-luxury-gold/30 p-10 text-center cursor-pointer group"
            style={{ background: 'linear-gradient(135deg, rgba(212,175,55,0.08) 0%, rgba(11,11,11,1) 50%, rgba(212,175,55,0.06) 100%)' }}
          >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.12)_0%,_transparent_60%)] pointer-events-none" />
            <p className="text-luxury-gold text-xs tracking-widest uppercase mb-3">Limited Offer</p>
            <h3 className="text-3xl sm:text-4xl font-playfair font-bold mb-3">
              Get <span className="text-luxury-gold">20% Off</span> Your First Order
            </h3>
            <p className="text-luxury-light/60 mb-6">
              Use code <span className="text-luxury-gold font-bold">YOURCHOICE20</span> at checkout
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="inline-flex items-center gap-2 px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl"
            >
              Claim Offer <ArrowRight className="w-4 h-4" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-16 px-4 bg-white/[0.015]">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-luxury-gold text-xs tracking-widest uppercase mb-2">Just In</p>
              <h2 className="text-3xl font-playfair font-bold">New Arrivals</h2>
            </div>
            <button onClick={() => navigate('/shop')} className="flex items-center gap-1 text-sm text-luxury-gold hover:underline">
              View All <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.slice(0, 8).map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-14 px-4 border-t border-luxury-gold/10">
        <div className="max-w-xl mx-auto text-center">
          <p className="text-luxury-gold text-xs tracking-widest uppercase mb-3">Stay Updated</p>
          <h2 className="text-2xl font-playfair font-bold mb-2">Subscribe to Our Newsletter</h2>
          <p className="text-luxury-light/50 text-sm mb-6">Exclusive offers, new arrivals, and fashion tips.</p>
          {subscribed ? (
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="py-3 px-6 bg-luxury-gold/15 border border-luxury-gold/30 rounded-xl text-luxury-gold font-semibold text-sm">
              🎉 Thank you for subscribing!
            </motion.div>
          ) : (
            <form onSubmit={e => { e.preventDefault(); if (email) setSubscribed(true) }} className="flex gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 px-4 py-2.5 bg-white/5 border border-luxury-gold/25 rounded-lg text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors"
              />
              <button type="submit" className="px-6 py-2.5 bg-luxury-gold text-luxury-black font-bold rounded-lg text-sm hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all">
                Subscribe
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  )
}
