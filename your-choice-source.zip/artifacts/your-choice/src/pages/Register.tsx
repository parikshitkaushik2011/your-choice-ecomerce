import { useState } from 'react'
import { useLocation, Link } from 'wouter'
import { motion } from 'framer-motion'
import { Eye, EyeOff, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '../store'

export default function Register() {
  const { register } = useApp()
  const [, navigate] = useLocation()
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' })
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirm) { setError('Passwords do not match'); return }
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return }
    if (form.phone.length !== 10) { setError('Enter a valid 10-digit phone number'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 700))
    const ok = register(form.name.trim(), form.email.trim(), form.password, form.phone.trim())
    setLoading(false)
    if (ok) {
      toast.success('Account created! Welcome to Your Choice 🎉')
      navigate('/')
    } else {
      setError('An account with this email already exists.')
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-playfair font-bold text-luxury-gold mb-2">Create Account</h1>
          <p className="text-luxury-light/50 text-sm">Join Your Choice for exclusive offers</p>
        </div>

        <div className="border border-luxury-gold/20 rounded-3xl p-8 bg-white/[0.02]">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Full Name *</label>
                <input required value={form.name} onChange={set('name')} placeholder="Arvind Kaushik" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
              </div>
              <div>
                <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Phone *</label>
                <input required value={form.phone} onChange={set('phone')} type="tel" placeholder="9467259111" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
              </div>
            </div>

            <div>
              <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Email *</label>
              <input required type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
            </div>

            <div>
              <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Password *</label>
              <div className="relative">
                <input required type={show ? 'text' : 'password'} value={form.password} onChange={set('password')} placeholder="Min 6 characters" className="w-full px-4 py-2.5 pr-11 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
                <button type="button" onClick={() => setShow(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-luxury-light/40 hover:text-luxury-gold">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Confirm Password *</label>
              <input required type="password" value={form.confirm} onChange={set('confirm')} placeholder="Re-enter password" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
            </div>

            {error && (
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                {error}
              </motion.p>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: loading ? 1 : 1.02 }}
              whileTap={{ scale: 0.97 }}
              className="w-full py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2 disabled:opacity-70 mt-2"
            >
              {loading ? <span className="w-5 h-5 border-2 border-luxury-black/40 border-t-luxury-black rounded-full animate-spin" /> : <><UserPlus className="w-4 h-4" /> Create Account</>}
            </motion.button>
          </form>

          <p className="text-center text-sm text-luxury-light/40 mt-5">
            Already have an account?{' '}
            <Link href="/login" className="text-luxury-gold hover:underline font-semibold">Sign In</Link>
          </p>
        </div>
      </motion.div>
    </div>
  )
}
