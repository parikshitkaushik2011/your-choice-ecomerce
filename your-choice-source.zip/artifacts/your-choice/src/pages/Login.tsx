import { useState } from 'react'
import { useLocation, Link } from 'wouter'
import { motion } from 'framer-motion'
import { Eye, EyeOff, LogIn } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '../store'

export default function Login() {
  const { login } = useApp()
  const [, navigate] = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    await new Promise(r => setTimeout(r, 700))
    const ok = login(email.trim(), password)
    setLoading(false)
    if (ok) {
      toast.success('Welcome back!', { icon: '👋' })
      navigate('/')
    } else {
      setError('Invalid email or password. Try registering first.')
    }
  }

  const demoLogin = () => {
    setEmail('admin@yourchoice.com')
    setPassword('admin123')
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-playfair font-bold text-luxury-gold mb-2">Welcome Back</h1>
          <p className="text-luxury-light/50 text-sm">Sign in to your Your Choice account</p>
        </div>

        <div className="border border-luxury-gold/20 rounded-3xl p-8 bg-white/[0.02] backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Password</label>
              <div className="relative">
                <input
                  type={show ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 pr-11 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors"
                />
                <button type="button" onClick={() => setShow(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-luxury-light/40 hover:text-luxury-gold transition-colors">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                {error}
              </motion.p>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: loading ? 1 : 1.02 }}
              whileTap={{ scale: 0.97 }}
              className="w-full py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {loading ? <span className="w-5 h-5 border-2 border-luxury-black/40 border-t-luxury-black rounded-full animate-spin" /> : <><LogIn className="w-4 h-4" /> Sign In</>}
            </motion.button>
          </form>

          <div className="mt-5 pt-5 border-t border-luxury-gold/10">
            <button
              onClick={demoLogin}
              className="w-full py-2.5 border border-luxury-gold/20 text-luxury-light/60 text-sm rounded-xl hover:text-luxury-gold hover:border-luxury-gold/40 transition-colors"
            >
              Use Demo Admin Account
            </button>
          </div>

          <p className="text-center text-sm text-luxury-light/40 mt-5">
            Don't have an account?{' '}
            <Link href="/register" className="text-luxury-gold hover:underline font-semibold">Register</Link>
          </p>
        </div>
      </motion.div>
    </div>
  )
}
