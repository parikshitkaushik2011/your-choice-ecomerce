import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { Package, ShoppingBag, Users, TrendingUp, Eye, Edit, Trash2, Plus, BarChart3 } from 'lucide-react'
import { products } from '../data/products'
import { useApp } from '../store'

const TABS = ['Dashboard', 'Products', 'Orders'] as const

export default function Admin() {
  const { user, orders } = useApp()
  const [, navigate] = useLocation()
  const [tab, setTab] = useState<typeof TABS[number]>('Dashboard')

  if (!user || user.email !== 'admin@yourchoice.com') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">🔒</div>
        <h2 className="text-2xl font-playfair font-bold mb-3">Admin Access Only</h2>
        <p className="text-luxury-light/50 text-sm mb-6">Login with the admin account to access this panel.</p>
        <button onClick={() => navigate('/login')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Login as Admin</button>
      </div>
    )
  }

  const totalRevenue = orders.reduce((s, o) => s + o.total, 0)
  const pendingOrders = orders.filter(o => o.status === 'Confirmed' || o.status === 'Processing').length
  const categoryCount = {
    men: products.filter(p => p.category === 'men').length,
    women: products.filter(p => p.category === 'women').length,
    kids: products.filter(p => p.category === 'kids').length,
    accessories: products.filter(p => p.category === 'accessories').length,
  }

  const stats = [
    { icon: TrendingUp, label: 'Total Revenue', val: `₹${totalRevenue.toLocaleString()}`, sub: `${orders.length} orders`, color: 'text-luxury-gold' },
    { icon: Package, label: 'Products', val: products.length, sub: '4 categories', color: 'text-blue-400' },
    { icon: ShoppingBag, label: 'Pending Orders', val: pendingOrders, sub: 'Need attention', color: 'text-yellow-400' },
    { icon: Users, label: 'Customers', val: orders.length + 3, sub: 'Registered users', color: 'text-green-400' },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">Control Panel</p>
          <h1 className="text-3xl font-playfair font-bold">Admin Dashboard</h1>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-luxury-gold/10 border border-luxury-gold/20 rounded-lg">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-xs text-luxury-gold font-medium">Live</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-white/[0.03] border border-luxury-gold/15 rounded-xl p-1 w-fit">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === t ? 'bg-luxury-gold text-luxury-black' : 'text-luxury-light/60 hover:text-luxury-gold'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Dashboard Tab */}
      {tab === 'Dashboard' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {/* Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map(({ icon: Icon, label, val, sub, color }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="p-5 border border-luxury-gold/15 rounded-2xl bg-white/[0.02]"
              >
                <div className="flex items-center justify-between mb-3">
                  <Icon className={`w-6 h-6 ${color}`} />
                  <BarChart3 className="w-4 h-4 text-luxury-light/20" />
                </div>
                <p className="text-2xl font-playfair font-bold text-luxury-gold">{val}</p>
                <p className="text-xs font-semibold text-luxury-light/80 mt-1">{label}</p>
                <p className="text-[10px] text-luxury-light/40 mt-0.5">{sub}</p>
              </motion.div>
            ))}
          </div>

          {/* Category Breakdown */}
          <div className="grid sm:grid-cols-2 gap-6 mb-8">
            <div className="border border-luxury-gold/15 rounded-2xl p-5 bg-white/[0.02]">
              <h3 className="font-playfair font-bold text-luxury-gold mb-4">Product by Category</h3>
              <div className="space-y-3">
                {Object.entries(categoryCount).map(([cat, count]) => (
                  <div key={cat}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="capitalize text-luxury-light/70">{cat}</span>
                      <span className="text-luxury-gold font-semibold">{count}</span>
                    </div>
                    <div className="w-full bg-luxury-gold/10 rounded-full h-1.5">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(count / products.length) * 100}%` }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="bg-luxury-gold h-1.5 rounded-full"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border border-luxury-gold/15 rounded-2xl p-5 bg-white/[0.02]">
              <h3 className="font-playfair font-bold text-luxury-gold mb-4">Order Status</h3>
              {orders.length === 0 ? (
                <p className="text-luxury-light/40 text-sm text-center py-4">No orders yet</p>
              ) : (
                <div className="space-y-3">
                  {['Confirmed', 'Processing', 'Shipped', 'Delivered'].map(status => {
                    const count = orders.filter(o => o.status === status).length
                    const pct = orders.length ? (count / orders.length) * 100 : 0
                    const colors: Record<string, string> = { Confirmed: 'bg-blue-400', Processing: 'bg-yellow-400', Shipped: 'bg-purple-400', Delivered: 'bg-green-400' }
                    return (
                      <div key={status}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-luxury-light/70">{status}</span>
                          <span className="text-luxury-gold font-semibold">{count}</span>
                        </div>
                        <div className="w-full bg-luxury-gold/10 rounded-full h-1.5">
                          <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8 }} className={`h-1.5 rounded-full ${colors[status]}`} />
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Recent Orders */}
          {orders.length > 0 && (
            <div className="border border-luxury-gold/15 rounded-2xl bg-white/[0.02] overflow-hidden">
              <div className="flex items-center justify-between px-5 py-4 border-b border-luxury-gold/10">
                <h3 className="font-playfair font-bold text-luxury-gold">Recent Orders</h3>
                <button onClick={() => setTab('Orders')} className="text-xs text-luxury-gold hover:underline">View All</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-luxury-gold/10">
                      {['Order ID', 'Items', 'Total', 'Status', 'Date'].map(h => (
                        <th key={h} className="text-left px-5 py-3 text-xs text-luxury-light/40 uppercase tracking-widest font-medium">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 5).map(o => (
                      <tr key={o.id} className="border-b border-luxury-gold/5 hover:bg-luxury-gold/[0.02] transition-colors">
                        <td className="px-5 py-3 font-mono text-xs text-luxury-gold">{o.id}</td>
                        <td className="px-5 py-3 text-luxury-light/70">{o.items.length} item{o.items.length !== 1 ? 's' : ''}</td>
                        <td className="px-5 py-3 font-semibold text-luxury-gold">₹{o.total.toLocaleString()}</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${
                            o.status === 'Delivered' ? 'text-green-400 bg-green-500/10 border-green-500/20' :
                            o.status === 'Shipped' ? 'text-purple-400 bg-purple-500/10 border-purple-500/20' :
                            o.status === 'Processing' ? 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' :
                            'text-blue-400 bg-blue-500/10 border-blue-500/20'
                          }`}>{o.status}</span>
                        </td>
                        <td className="px-5 py-3 text-luxury-light/50 text-xs">{o.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* Products Tab */}
      {tab === 'Products' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="flex items-center justify-between mb-5">
            <p className="text-luxury-light/50 text-sm">{products.length} products</p>
            <button className="flex items-center gap-1.5 px-4 py-2 bg-luxury-gold text-luxury-black text-sm font-bold rounded-lg">
              <Plus className="w-4 h-4" /> Add Product
            </button>
          </div>
          <div className="border border-luxury-gold/15 rounded-2xl bg-white/[0.02] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-luxury-gold/10">
                    {['Product', 'Category', 'Price', 'Stock', 'Actions'].map(h => (
                      <th key={h} className="text-left px-5 py-3 text-xs text-luxury-light/40 uppercase tracking-widest font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id} className="border-b border-luxury-gold/5 hover:bg-luxury-gold/[0.02] transition-colors">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{p.emoji}</span>
                          <div>
                            <p className="font-medium text-xs">{p.name}</p>
                            <p className="text-[10px] text-luxury-light/40">{p.subcategory}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3 capitalize text-luxury-light/70 text-xs">{p.category}</td>
                      <td className="px-5 py-3">
                        <p className="text-luxury-gold font-semibold text-xs">₹{p.price.toLocaleString()}</p>
                        <p className="text-luxury-light/30 line-through text-[10px]">₹{p.originalPrice.toLocaleString()}</p>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${p.inStock ? 'text-green-400 bg-green-500/10 border-green-500/20' : 'text-red-400 bg-red-500/10 border-red-500/20'}`}>
                          {p.inStock ? 'In Stock' : 'Out of Stock'}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 text-luxury-light/40 hover:text-luxury-gold transition-colors"><Eye className="w-3.5 h-3.5" /></button>
                          <button className="p-1.5 text-luxury-light/40 hover:text-luxury-gold transition-colors"><Edit className="w-3.5 h-3.5" /></button>
                          <button className="p-1.5 text-luxury-light/40 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      )}

      {/* Orders Tab */}
      {tab === 'Orders' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {orders.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingBag className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
              <p className="text-luxury-light/50">No orders placed yet</p>
            </div>
          ) : (
            <div className="border border-luxury-gold/15 rounded-2xl bg-white/[0.02] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-luxury-gold/10">
                      {['Order ID', 'Customer', 'Items', 'Total', 'Payment', 'Status', 'Date'].map(h => (
                        <th key={h} className="text-left px-5 py-3 text-xs text-luxury-light/40 uppercase tracking-widest font-medium">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(o => (
                      <tr key={o.id} className="border-b border-luxury-gold/5 hover:bg-luxury-gold/[0.02] transition-colors">
                        <td className="px-5 py-3 font-mono text-xs text-luxury-gold">{o.id}</td>
                        <td className="px-5 py-3 text-xs">
                          <p className="font-medium">{o.address.fullName}</p>
                          <p className="text-luxury-light/40">{o.address.city}</p>
                        </td>
                        <td className="px-5 py-3 text-luxury-light/70 text-xs">{o.items.length}</td>
                        <td className="px-5 py-3 font-semibold text-luxury-gold text-xs">₹{o.total.toLocaleString()}</td>
                        <td className="px-5 py-3 text-luxury-light/60 text-xs capitalize">{o.paymentMethod}</td>
                        <td className="px-5 py-3">
                          <select defaultValue={o.status} className="bg-luxury-black border border-luxury-gold/20 rounded text-xs px-2 py-1 text-luxury-gold focus:outline-none cursor-pointer">
                            {['Confirmed', 'Processing', 'Shipped', 'Delivered'].map(s => (
                              <option key={s} value={s} className="bg-luxury-black">{s}</option>
                            ))}
                          </select>
                        </td>
                        <td className="px-5 py-3 text-luxury-light/40 text-xs">{o.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  )
}
