import { useSearch, useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { CheckCircle, Package, ArrowRight } from 'lucide-react'

export default function OrderSuccess() {
  const search = useSearch()
  const params = new URLSearchParams(search)
  const orderId = params.get('id') || 'YC' + Date.now()
  const [, navigate] = useLocation()

  return (
    <div className="max-w-2xl mx-auto px-4 py-20 text-center">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 15 }}
        className="w-24 h-24 bg-green-500/10 border-2 border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-6"
      >
        <CheckCircle className="w-12 h-12 text-green-400" />
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <h1 className="text-3xl font-playfair font-bold mb-2">Order Placed!</h1>
        <p className="text-luxury-light/60 mb-2">Thank you for shopping with Your Choice 🎉</p>
        <div className="inline-block px-4 py-2 bg-luxury-gold/10 border border-luxury-gold/30 rounded-lg mb-8">
          <p className="text-xs text-luxury-light/50 uppercase tracking-widest">Order ID</p>
          <p className="font-playfair font-bold text-luxury-gold text-lg">{orderId}</p>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-10 text-center">
          {[
            { icon: '✅', title: 'Order Confirmed', desc: 'We\'ve received your order' },
            { icon: '📦', title: 'Processing', desc: 'Being carefully packed' },
            { icon: '🚚', title: 'Delivery', desc: '3-5 business days' },
          ].map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="p-4 border border-luxury-gold/15 rounded-xl bg-white/[0.02]"
            >
              <p className="text-2xl mb-2">{s.icon}</p>
              <p className="font-semibold text-xs">{s.title}</p>
              <p className="text-luxury-light/40 text-[10px] mt-1">{s.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="p-5 bg-luxury-gold/5 border border-luxury-gold/20 rounded-2xl mb-8 text-left">
          <div className="flex items-center gap-2 mb-3">
            <Package className="w-5 h-5 text-luxury-gold" />
            <p className="font-semibold text-luxury-gold">What happens next?</p>
          </div>
          <ul className="space-y-2 text-sm text-luxury-light/60">
            <li>• You'll receive an SMS/WhatsApp confirmation shortly</li>
            <li>• Our team will confirm your order within 1 business day</li>
            <li>• Track your order from the <strong className="text-luxury-light">My Orders</strong> page</li>
            <li>• For queries, WhatsApp us at <strong className="text-luxury-gold">9467259111</strong></li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => navigate('/orders')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
          >
            View My Orders <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => navigate('/shop')}
            className="px-6 py-3 border border-luxury-gold/30 text-luxury-gold rounded-xl hover:bg-luxury-gold/5 transition-colors font-semibold"
          >
            Continue Shopping
          </button>
        </div>
      </motion.div>
    </div>
  )
}
