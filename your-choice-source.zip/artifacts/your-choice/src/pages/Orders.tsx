import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { Package, MapPin, CreditCard, ArrowRight, ShoppingBag } from 'lucide-react'
import { useApp } from '../store'

const STATUS_COLORS: Record<string, string> = {
  'Confirmed': 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  'Processing': 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
  'Shipped': 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  'Delivered': 'text-green-400 bg-green-500/10 border-green-500/20',
}

const STATUS_ICONS: Record<string, string> = {
  'Confirmed': '✅',
  'Processing': '📦',
  'Shipped': '🚚',
  'Delivered': '🎉',
}

export default function Orders() {
  const { orders, user } = useApp()
  const [, navigate] = useLocation()

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <Package className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
        <h2 className="text-2xl font-playfair font-bold mb-3">Please sign in to view orders</h2>
        <button onClick={() => navigate('/login')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Sign In</button>
      </div>
    )
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <ShoppingBag className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
        <h2 className="text-2xl font-playfair font-bold mb-2">No orders yet</h2>
        <p className="text-luxury-light/50 text-sm mb-6">Start shopping to see your orders here</p>
        <button onClick={() => navigate('/shop')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Shop Now</button>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-playfair font-bold mb-8">My Orders</h1>

      <div className="space-y-5">
        {orders.map((order, i) => (
          <motion.div
            key={order.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="border border-luxury-gold/15 rounded-2xl bg-white/[0.02] overflow-hidden hover:border-luxury-gold/30 transition-colors"
          >
            {/* Order Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 border-b border-luxury-gold/10 bg-luxury-gold/[0.02]">
              <div>
                <p className="text-xs text-luxury-light/40 uppercase tracking-widest">Order ID</p>
                <p className="font-playfair font-bold text-luxury-gold">{order.id}</p>
              </div>
              <div className="hidden sm:block">
                <p className="text-xs text-luxury-light/40 uppercase tracking-widest">Date</p>
                <p className="text-sm font-medium">{order.date}</p>
              </div>
              <div>
                <p className="text-xs text-luxury-light/40 uppercase tracking-widest">Total</p>
                <p className="font-bold text-luxury-gold">₹{order.total.toLocaleString()}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${STATUS_COLORS[order.status]}`}>
                {STATUS_ICONS[order.status]} {order.status}
              </span>
            </div>

            {/* Items */}
            <div className="px-5 py-4">
              <div className="flex gap-3 flex-wrap mb-4">
                {order.items.map((item, j) => (
                  <div
                    key={j}
                    className="flex items-center gap-2 px-3 py-2 bg-luxury-gold/5 border border-luxury-gold/10 rounded-xl cursor-pointer hover:border-luxury-gold/30 transition-colors"
                    onClick={() => navigate(`/product/${item.product.id}`)}
                  >
                    <span className="text-2xl">{item.product.emoji}</span>
                    <div>
                      <p className="text-xs font-semibold">{item.product.name}</p>
                      <p className="text-[10px] text-luxury-light/40">Size: {item.size} × {item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Details */}
              <div className="grid sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-start gap-2 text-luxury-light/50">
                  <MapPin className="w-4 h-4 text-luxury-gold shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs uppercase tracking-widest text-luxury-light/30 mb-0.5">Deliver to</p>
                    <p className="text-xs">{order.address.fullName}</p>
                    <p className="text-xs text-luxury-light/40">{order.address.city}, {order.address.state}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 text-luxury-light/50">
                  <CreditCard className="w-4 h-4 text-luxury-gold shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs uppercase tracking-widest text-luxury-light/30 mb-0.5">Payment</p>
                    <p className="text-xs">{order.paymentMethod}</p>
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-4 pt-4 border-t border-luxury-gold/10">
                <div className="flex items-center justify-between gap-1">
                  {['Confirmed', 'Processing', 'Shipped', 'Delivered'].map((s, si) => {
                    const statuses = ['Confirmed', 'Processing', 'Shipped', 'Delivered']
                    const currentIdx = statuses.indexOf(order.status)
                    const isActive = si <= currentIdx
                    const isCurrent = si === currentIdx
                    return (
                      <div key={s} className="flex-1 flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full border-2 transition-colors ${isActive ? 'bg-luxury-gold border-luxury-gold' : 'border-luxury-gold/20 bg-transparent'} ${isCurrent ? 'ring-2 ring-luxury-gold/30' : ''}`} />
                        {si < 3 && <div className={`h-px flex-1 w-full mt-1.5 mx-1 transition-colors ${si < currentIdx ? 'bg-luxury-gold' : 'bg-luxury-gold/15'}`} style={{ position: 'relative', top: '-8px', left: '50%', width: 'calc(100% - 8px)' }} />}
                        <p className={`text-[9px] mt-1.5 hidden sm:block ${isActive ? 'text-luxury-gold' : 'text-luxury-light/25'}`}>{s}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 text-center">
        <button onClick={() => navigate('/shop')} className="flex items-center gap-2 mx-auto text-luxury-gold text-sm hover:underline">
          Continue Shopping <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}
