import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { Heart, ShoppingBag } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import { useApp } from '../store'

export default function Wishlist() {
  const { wishlistItems, user } = useApp()
  const [, navigate] = useLocation()

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <Heart className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
        <h2 className="text-2xl font-playfair font-bold mb-3">Please sign in to view your wishlist</h2>
        <button onClick={() => navigate('/login')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Sign In</button>
      </div>
    )
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Heart className="w-20 h-20 text-luxury-gold/20 mx-auto mb-6" />
          <h2 className="text-2xl font-playfair font-bold mb-2">Your wishlist is empty</h2>
          <p className="text-luxury-light/50 text-sm mb-8">Save items you love by tapping the ❤️ on any product</p>
          <button onClick={() => navigate('/shop')} className="flex items-center gap-2 mx-auto px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">
            <ShoppingBag className="w-4 h-4" /> Explore Products
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">Saved Items</p>
          <h1 className="text-3xl font-playfair font-bold">My Wishlist</h1>
        </div>
        <span className="text-luxury-light/50 text-sm">{wishlistItems.length} item{wishlistItems.length !== 1 ? 's' : ''}</span>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {wishlistItems.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
